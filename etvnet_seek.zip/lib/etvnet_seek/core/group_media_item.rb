class GroupMediaItem < MediaItem

  def to_s
    "#{text} ---  #{link}"
  end

end
